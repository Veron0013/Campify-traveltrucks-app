export const ERROR_MAIN_MESSAGE: string = 'Oops. Seems like error. Try again later';
export const LOADING_MAIN_MESSAGE: string = 'Plaese wait. Downloading data...';

export const LIMIT = 3;

export const SCROLL_THRESHOLD = 300;

export const SELECT_DATE = 'Select a date between today';
